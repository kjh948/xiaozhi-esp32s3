#ifndef _CAMERA_HTTP__H_
#define _CAMERA_HTTP__H_

void http_server_init(void);

#endif
#ifndef _WIFI_DRIVER__H_
#define _WIFI_DRIVER__H_

void WIFI_Init(void);
void WIFI_Init_Softap(const char *APSSID,const char *APPASS);
#endif